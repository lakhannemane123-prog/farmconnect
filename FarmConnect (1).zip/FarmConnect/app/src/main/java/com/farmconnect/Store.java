package com.farmconnect;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;
import com.google.gson.Gson;
import java.io.ByteArrayOutputStream;
import java.util.*;

/** App state, saved as JSON in SharedPreferences. Swap for Firebase/REST later. */
public class Store {
    public static class Listing { public int id, qty, price; public String farmer, village, crop, photo; }
    public static class Order {
        public int id, listingId, qty, price, fare, offerFare, rating;
        public String crop, farmer, village, dest, payment, customer, transporter, offerBy, otp, issue, status = "PLACED";
        public boolean paid, issueResolved;
        public long created;
        public int total() { return qty * price; }
    }
    public static class Notif { public String phone, msg; public long time; public boolean read; }
    public static class Data {
        public List<Listing> listings = new ArrayList<>();
        public List<Order> orders = new ArrayList<>();
        public List<Notif> notifs = new ArrayList<>();
        public int seq = 100;
    }
    public static Data d = new Data();
    public static String phone;
    public static int role = -1;          // 0 farmer, 1 customer, 2 transporter
    public static boolean online = true;
    private static SharedPreferences sp;

    static final String[] PLACES = {"Satara", "Nashik", "Pune", "Kolhapur", "Nagpur", "Mumbai", "Solapur", "Ahmednagar"};
    static final double[][] XY = {{17.68, 74.00}, {19.99, 73.79}, {18.52, 73.86}, {16.70, 74.24},
                                  {21.15, 79.09}, {19.08, 72.88}, {17.66, 75.91}, {19.09, 74.74}};
    static final String[] LANGS = {"en", "hi", "mr"};

    public static void init(Context c) {
        if (sp != null) return;
        sp = c.getApplicationContext().getSharedPreferences("fc", 0);
        String j = sp.getString("data", null);
        if (j != null) d = new Gson().fromJson(j, Data.class);
        if (d.listings.isEmpty()) {
            d.listings.add(mk("9000000001", "Satara", "Tomato", 100, 30));
            d.listings.add(mk("9000000002", "Nashik", "Onion", 250, 18));
        }
        phone = sp.getString("phone", null);
        role = sp.getInt("role", -1);
    }
    private static Listing mk(String f, String v, String c, int q, int p) {
        Listing l = new Listing(); l.id = d.seq++; l.farmer = f; l.village = v; l.crop = c; l.qty = q; l.price = p; return l;
    }
    public static Listing add(String f, String v, String c, int q, int p, String photo) {
        Listing l = mk(f, v, c, q, p); l.photo = photo; d.listings.add(l); return l;
    }
    public static void save() { if (sp != null) sp.edit().putString("data", new Gson().toJson(d)).apply(); }
    public static void login(String p, int r) { phone = p; role = r; sp.edit().putString("phone", p).putInt("role", r).apply(); }
    public static void logout() { phone = null; role = -1; sp.edit().remove("phone").remove("role").apply(); }
    public static void setLang(int i) { AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(LANGS[i])); }
    public static int num(String s) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; } }

    static int idx(String p) { for (int i = 0; i < PLACES.length; i++) if (PLACES[i].equals(p)) return i; return 0; }
    public static int km(String a, String b) {
        double[] p = XY[idx(a)], q = XY[idx(b)];
        double dx = (p[0] - q[0]) * 111, dy = (p[1] - q[1]) * 111 * Math.cos(Math.toRadians(p[0]));
        return (int) Math.round(Math.sqrt(dx * dx + dy * dy));
    }
    public static int fare(String a, String b, int qty) { return 50 + km(a, b) * 8 + qty / 2; }

    public static Listing listing(int id) { for (Listing l : d.listings) if (l.id == id) return l; return null; }
    public static void restock(Order o) { Listing l = listing(o.listingId); if (l != null) l.qty += o.qty; }

    public static Order place(Listing l, int qty, String cust, String dest, int pay) {
        Order o = new Order();
        o.id = d.seq++; o.listingId = l.id; o.crop = l.crop; o.farmer = l.farmer; o.village = l.village;
        o.qty = qty; o.price = l.price; o.customer = cust; o.dest = dest;
        o.payment = pay == 0 ? "UPI" : "COD"; o.paid = pay == 0;
        o.fare = fare(l.village, dest, qty);
        o.otp = String.valueOf(1000 + new Random().nextInt(9000));
        o.created = System.currentTimeMillis();
        l.qty -= qty;                                     // prevents overselling
        d.orders.add(o);
        notify(l.farmer, "New order #" + o.id + ": " + qty + " kg " + l.crop);
        return o;
    }
    public static void notify(String to, String msg) {
        Notif n = new Notif(); n.phone = to; n.msg = msg; n.time = System.currentTimeMillis(); d.notifs.add(n);
    }
    public static int unread(String p) { int c = 0; for (Notif n : d.notifs) if (n.phone.equals(p) && !n.read) c++; return c; }
    public static void markRead(String p) { for (Notif n : d.notifs) if (n.phone.equals(p)) n.read = true; }
    public static double rating(String farmer) {
        int n = 0, s = 0;
        for (Order o : d.orders) if (o.farmer.equals(farmer) && o.rating > 0) { n++; s += o.rating; }
        return n == 0 ? 0 : (double) s / n;
    }
    /** Unaccepted orders older than 24h are cancelled automatically. */
    public static void expire() {
        long now = System.currentTimeMillis();
        for (Order o : d.orders)
            if (o.status.equals("PLACED") && now - o.created > 24L * 3600 * 1000) {
                o.status = "CANCELLED"; restock(o); notify(o.customer, "Order #" + o.id + " auto-cancelled (no reply)");
            }
    }
    public static String statusText(Context c, Order o) {
        int id = c.getResources().getIdentifier("st_" + o.status.toLowerCase(), "string", c.getPackageName());
        return c.getString(id);
    }
    public static int color(String s) {
        switch (s) {
            case "PLACED": return 0xFFF9A825;
            case "ACCEPTED": return 0xFF1E88E5;
            case "OFFER": return 0xFF8E24AA;
            case "ASSIGNED": return 0xFF00897B;
            case "IN_TRANSIT": return 0xFF3949AB;
            case "DELIVERED": return 0xFF2E7D32;
            default: return 0xFFC62828;
        }
    }
    public static String encode(Bitmap b) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.JPEG, 70, o);
        return Base64.encodeToString(o.toByteArray(), Base64.DEFAULT);
    }
    public static Bitmap decode(String s) {
        byte[] b = Base64.decode(s, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(b, 0, b.length);
    }
}
