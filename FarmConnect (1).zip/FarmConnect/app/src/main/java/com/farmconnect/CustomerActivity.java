package com.farmconnect;

import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import com.farmconnect.RowAdapter.Row;
import java.util.*;

public class CustomerActivity extends BaseActivity {
    @Override protected int navMenu() { return R.menu.nav_customer; }
    @Override protected boolean searchable() { return true; }

    @Override protected void onSpeech(String t) {
        int i = cropFrom(t);
        etSearch.setText(i >= 0 ? getResources().getStringArray(R.array.crops)[i] : t);
    }

    @Override protected List<Row> rows(int t) {
        List<Row> rows = new ArrayList<>();
        if (t == R.id.t1) {
            String q = etSearch.getText().toString().toLowerCase().trim();
            for (Store.Listing l : Store.d.listings) {
                if (l.qty <= 0) continue;
                if (!q.isEmpty() && !(l.crop + " " + l.village).toLowerCase().contains(q)) continue;
                double r = Store.rating(l.farmer);
                String sub = l.village + " · " + l.qty + " kg" + (r > 0 ? " · " + getString(R.string.rating, r) : "");
                rows.add(new Row(l.crop + " · ₹" + l.price + "/kg", sub).photo(l.photo)
                    .chip(getString(R.string.available), 0xFF2E7D32)
                    .btn(getString(R.string.order), () -> orderDialog(l)));
            }
        } else {
            for (int i = Store.d.orders.size() - 1; i >= 0; i--) {
                Store.Order o = Store.d.orders.get(i);
                if (!o.customer.equals(Store.phone)) continue;
                String sub = "₹" + o.total() + " + ₹" + o.fare + " · " + o.payment + (o.paid ? " ✔" : "");
                if (o.status.equals("ASSIGNED")) sub += "\n" + getString(R.string.pickup_eta, o.transporter);
                if (o.status.equals("ASSIGNED") || o.status.equals("IN_TRANSIT")) sub += "\n" + getString(R.string.otp_label, o.otp);
                if (o.issue != null) sub += "\n⚠ " + getString(R.string.issue_label, o.issue) + (o.issueResolved ? " ✔" : "");
                Row r = new Row("#" + o.id + " " + o.crop + " · " + o.qty + " kg", sub)
                    .chip(Store.statusText(this, o), Store.color(o.status));
                switch (o.status) {
                    case "PLACED":
                        r.btn(getString(R.string.cancel), () -> {
                            o.status = "CANCELLED"; Store.restock(o); Store.notify(o.farmer, "Order #" + o.id + " cancelled by customer"); refresh(); });
                        break;
                    case "OFFER":
                        r.btn(getString(R.string.approve, o.offerFare), () -> {
                            o.fare = o.offerFare; o.transporter = o.offerBy; o.status = "ASSIGNED";
                            Store.notify(o.transporter, "Your fare for #" + o.id + " was approved");
                            Store.notify(o.farmer, "Pickup for #" + o.id + " by " + o.transporter + " in ~30 min"); refresh(); });
                        r.btn(getString(R.string.decline), () -> {
                            Store.notify(o.offerBy, "Your fare for #" + o.id + " was declined");
                            o.status = "ACCEPTED"; o.offerBy = null; refresh(); });
                        break;
                    case "DELIVERED":
                        if (o.rating == 0) r.btn(getString(R.string.rate), () -> rateDialog(o));
                        if (o.issue == null) r.btn(getString(R.string.report_issue), () -> issueDialog(o));
                        break;
                }
                rows.add(r);
            }
        }
        return rows;
    }

    private void orderDialog(Store.Listing l) {
        View v = getLayoutInflater().inflate(R.layout.dialog_order, null);
        EditText q = v.findViewById(R.id.dlQty);
        Spinner place = v.findViewById(R.id.dlPlace), pay = v.findViewById(R.id.dlPay);
        new AlertDialog.Builder(this).setTitle(l.crop + " · ₹" + l.price + "/kg").setView(v)
            .setPositiveButton(R.string.order, (d, w) -> {
                int n = Store.num(q.getText().toString());
                if (n <= 0) { toast(getString(R.string.fill_all)); return; }
                if (n > l.qty) { toast(getString(R.string.only_left, l.qty)); return; }
                Store.Order o = Store.place(l, n, Store.phone, place.getSelectedItem().toString(), pay.getSelectedItemPosition());
                toast(getString(R.string.placed_msg, o.total(), o.fare));
                refresh();
            }).setNegativeButton(R.string.cancel, null).show();
    }
    private void rateDialog(Store.Order o) {
        RatingBar rb = new RatingBar(this); rb.setNumStars(5); rb.setStepSize(1); rb.setRating(5);
        LinearLayout box = new LinearLayout(this); box.setGravity(Gravity.CENTER); box.addView(rb);
        new AlertDialog.Builder(this).setTitle(R.string.rate).setView(box)
            .setPositiveButton(R.string.ok, (d, w) -> { o.rating = Math.max(1, (int) rb.getRating()); refresh(); })
            .setNegativeButton(R.string.cancel, null).show();
    }
    private void issueDialog(Store.Order o) {
        String[] items = getResources().getStringArray(R.array.issues);
        new AlertDialog.Builder(this).setTitle(R.string.report_issue).setItems(items, (d, i) -> {
            o.issue = items[i]; Store.notify(o.farmer, "Issue on order #" + o.id + ": " + items[i]); refresh();
        }).show();
    }
}
