package com.farmconnect;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.*;

/** Shared screen: toolbar, search + voice, bottom tabs (t1, t2, t3=alerts), FAB, language, logout. */
public abstract class BaseActivity extends AppCompatActivity {
    protected RowAdapter adapter;
    protected int tab = R.id.t1;
    protected EditText etSearch;
    private TextView tvSummary, tvEmpty;
    private View searchBar;
    private FloatingActionButton fab;
    private BottomNavigationView nav;

    protected abstract int navMenu();
    protected abstract List<RowAdapter.Row> rows(int tab);
    protected String summary(int tab) { return null; }
    protected boolean searchable() { return false; }
    protected boolean hasFab() { return false; }
    protected boolean hasOnline() { return false; }
    protected void onFab() {}
    protected void onSpeech(String text) {}

    private final ActivityResultLauncher<Intent> speech = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), r -> {
            if (r.getData() == null) return;
            ArrayList<String> a = r.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (a != null && !a.isEmpty()) onSpeech(a.get(0));
        });

    protected void listen() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        try { speech.launch(i); } catch (Exception e) { toast("Voice input not available"); }
    }
    /** Maps spoken text (English/Hindi/Marathi) to an index in the crops array, or -1. */
    protected int cropFrom(String said) {
        String[] alias = getResources().getStringArray(R.array.crop_alias);
        String t = said.toLowerCase();
        for (int i = 0; i < alias.length; i++)
            for (String a : alias[i].split("\\|")) if (t.contains(a.toLowerCase())) return i;
        return -1;
    }
    protected void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        Store.init(this);
        if (Store.phone == null) { startActivity(new Intent(this, LoginActivity.class)); finish(); return; }
        setContentView(R.layout.activity_main);
        setSupportActionBar(findViewById(R.id.toolbar));
        getSupportActionBar().setSubtitle(Store.phone);
        tvSummary = findViewById(R.id.tvSummary); tvEmpty = findViewById(R.id.tvEmpty);
        searchBar = findViewById(R.id.searchBar); etSearch = findViewById(R.id.etSearch);
        fab = findViewById(R.id.fab); nav = findViewById(R.id.nav);
        adapter = new RowAdapter(this);
        ((ListView) findViewById(R.id.list)).setAdapter(adapter);
        nav.inflateMenu(navMenu());
        nav.setOnItemSelectedListener(i -> { tab = i.getItemId(); refresh(); return true; });
        fab.setOnClickListener(v -> onFab());
        findViewById(R.id.btnMic).setOnClickListener(v -> listen());
        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence c, int a, int b, int d) {}
            public void onTextChanged(CharSequence c, int a, int b, int d) {}
            public void afterTextChanged(Editable e) { refresh(); }
        });
        refresh();
    }
    @Override protected void onResume() { super.onResume(); if (adapter != null) refresh(); }

    protected void refresh() {
        Store.expire();
        List<RowAdapter.Row> rows;
        if (tab == R.id.t3) {
            rows = new ArrayList<>();
            for (int i = Store.d.notifs.size() - 1; i >= 0; i--) {
                Store.Notif n = Store.d.notifs.get(i);
                if (n.phone.equals(Store.phone))
                    rows.add(new RowAdapter.Row(n.msg, android.text.format.DateFormat.format("dd MMM, hh:mm a", n.time).toString()));
            }
            Store.markRead(Store.phone);
        } else rows = rows(tab);
        adapter.set(rows);
        tvEmpty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
        String sum = tab == R.id.t3 ? null : summary(tab);
        tvSummary.setVisibility(sum == null ? View.GONE : View.VISIBLE);
        if (sum != null) tvSummary.setText(sum);
        searchBar.setVisibility(searchable() && tab == R.id.t1 ? View.VISIBLE : View.GONE);
        fab.setVisibility(hasFab() && tab == R.id.t1 ? View.VISIBLE : View.GONE);
        BadgeDrawable b = nav.getOrCreateBadge(R.id.t3);
        int u = Store.unread(Store.phone); b.setVisible(u > 0); b.setNumber(u);
        Store.save();
    }

    @Override public boolean onCreateOptionsMenu(Menu m) { getMenuInflater().inflate(R.menu.menu_top, m); return true; }
    @Override public boolean onPrepareOptionsMenu(Menu m) {
        MenuItem o = m.findItem(R.id.action_online); o.setVisible(hasOnline()); o.setChecked(Store.online); return true;
    }
    @Override public boolean onOptionsItemSelected(MenuItem it) {
        int id = it.getItemId();
        if (id == R.id.action_online) { Store.online = !Store.online; it.setChecked(Store.online); refresh(); }
        else if (id == R.id.action_lang)
            new AlertDialog.Builder(this).setTitle(R.string.language)
                .setItems(new String[]{"English", "हिन्दी", "मराठी"}, (d, i) -> Store.setLang(i)).show();
        else if (id == R.id.action_logout) {
            Store.logout();
            startActivity(new Intent(this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        }
        return true;
    }
}
