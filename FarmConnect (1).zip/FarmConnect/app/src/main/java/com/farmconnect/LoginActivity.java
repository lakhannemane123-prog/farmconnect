package com.farmconnect;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private static final String DEMO_OTP = "1234"; // replace with a real SMS OTP service

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        Store.init(this);
        if (Store.phone != null) { go(Store.role); return; }
        setContentView(R.layout.activity_login);
        EditText phone = findViewById(R.id.etPhone), otp = findViewById(R.id.etOtp);
        Button send = findViewById(R.id.btnSend), verify = findViewById(R.id.btnVerify);
        Spinner role = findViewById(R.id.spRole);
        findViewById(R.id.btnEn).setOnClickListener(v -> Store.setLang(0));
        findViewById(R.id.btnHi).setOnClickListener(v -> Store.setLang(1));
        findViewById(R.id.btnMr).setOnClickListener(v -> Store.setLang(2));

        send.setOnClickListener(v -> {
            if (phone.getText().length() != 10) { phone.setError(getString(R.string.mobile)); return; }
            otp.setVisibility(View.VISIBLE); verify.setVisibility(View.VISIBLE);
            Toast.makeText(this, getString(R.string.otp_toast, DEMO_OTP), Toast.LENGTH_LONG).show();
            send.setEnabled(false);
            new CountDownTimer(30000, 1000) {
                public void onTick(long ms) { send.setText(getString(R.string.resend, ms / 1000)); }
                public void onFinish() { send.setEnabled(true); send.setText(R.string.send_otp); }
            }.start();
        });
        verify.setOnClickListener(v -> {
            if (!otp.getText().toString().equals(DEMO_OTP)) { otp.setError(getString(R.string.wrong_otp)); return; }
            Store.login(phone.getText().toString(), role.getSelectedItemPosition());
            go(Store.role);
        });
    }
    private void go(int role) {
        Class<?> c = role == 0 ? FarmerActivity.class : role == 1 ? CustomerActivity.class : TransporterActivity.class;
        startActivity(new Intent(this, c));
        finish();
    }
}
