package com.farmconnect;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import java.util.*;
import java.util.function.Consumer;

public class RowAdapter extends BaseAdapter {
    public static class Row {
        String title, sub, chip, photo; int chipColor;
        List<String> labels = new ArrayList<>(); List<Runnable> acts = new ArrayList<>();
        public Row(String t, String s) { title = t; sub = s; }
        public Row chip(String c, int color) { chip = c; chipColor = color; return this; }
        public Row photo(String p) { photo = p; return this; }
        public Row btn(String l, Runnable r) { labels.add(l); acts.add(r); return this; }
    }
    private List<Row> rows = new ArrayList<>();
    private final LayoutInflater inf;
    public RowAdapter(Context c) { inf = LayoutInflater.from(c); }
    public void set(List<Row> r) { rows = r; notifyDataSetChanged(); }
    @Override public int getCount() { return rows.size(); }
    @Override public Object getItem(int i) { return rows.get(i); }
    @Override public long getItemId(int i) { return i; }
    @Override public View getView(int i, View v, ViewGroup p) {
        if (v == null) v = inf.inflate(R.layout.item_row, p, false);
        Row r = rows.get(i);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(r.title);
        ((TextView) v.findViewById(R.id.tvSub)).setText(r.sub);
        TextView chip = v.findViewById(R.id.tvChip);
        chip.setVisibility(r.chip == null ? View.GONE : View.VISIBLE);
        if (r.chip != null) {
            GradientDrawable g = new GradientDrawable(); g.setCornerRadius(40); g.setColor(r.chipColor);
            chip.setBackground(g); chip.setText(r.chip);
        }
        ImageView iv = v.findViewById(R.id.ivPhoto);
        iv.setVisibility(r.photo == null ? View.GONE : View.VISIBLE);
        if (r.photo != null) iv.setImageBitmap(Store.decode(r.photo));
        int[] ids = {R.id.btnA, R.id.btnB, R.id.btnC};
        for (int k = 0; k < 3; k++) {
            Button b = v.findViewById(ids[k]);
            if (k < r.labels.size()) {
                Runnable act = r.acts.get(k);
                b.setVisibility(View.VISIBLE); b.setText(r.labels.get(k)); b.setOnClickListener(x -> act.run());
            } else b.setVisibility(View.GONE);
        }
        return v;
    }
    public static void prompt(Context c, String title, Consumer<String> ok) {
        EditText et = new EditText(c);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        new AlertDialog.Builder(c).setTitle(title).setView(et)
            .setPositiveButton(R.string.ok, (d, w) -> ok.accept(et.getText().toString().trim()))
            .setNegativeButton(R.string.cancel, null).show();
    }
}
