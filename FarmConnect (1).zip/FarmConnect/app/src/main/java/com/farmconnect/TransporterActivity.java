package com.farmconnect;

import com.farmconnect.RowAdapter.Row;
import java.util.*;

public class TransporterActivity extends BaseActivity {
    @Override protected int navMenu() { return R.menu.nav_transporter; }
    @Override protected boolean hasOnline() { return true; }

    @Override protected String summary(int t) {
        if (t == R.id.t1) return Store.online ? null : getString(R.string.offline);
        int sum = 0, n = 0;
        for (Store.Order o : Store.d.orders) if (Store.phone.equals(o.transporter) && o.status.equals("DELIVERED")) { sum += o.fare; n++; }
        return getString(R.string.earned, sum, n);
    }

    @Override protected List<Row> rows(int t) {
        List<Row> rows = new ArrayList<>();
        if (t == R.id.t1) {
            if (!Store.online) return rows;
            List<Store.Order> open = new ArrayList<>();
            for (Store.Order o : Store.d.orders) if (o.status.equals("ACCEPTED")) open.add(o);
            Collections.sort(open, (a, b) -> Store.km(a.village, a.dest) - Store.km(b.village, b.dest));   // nearest first
            for (Store.Order o : open)
                rows.add(new Row("#" + o.id + " " + o.crop + " · " + o.qty + " kg",
                        o.village + " → " + o.dest + " · " + Store.km(o.village, o.dest) + " km")
                    .chip("₹" + o.fare, 0xFF1E88E5)
                    .btn(getString(R.string.accept_fare, o.fare), () -> {
                        o.status = "ASSIGNED"; o.transporter = Store.phone;
                        Store.notify(o.customer, "Transporter " + Store.phone + " assigned for #" + o.id);
                        Store.notify(o.farmer, "Pickup for #" + o.id + " by " + Store.phone + " in ~30 min"); refresh(); })
                    .btn(getString(R.string.counter), () -> RowAdapter.prompt(this, getString(R.string.your_fare), v -> {
                        if (Store.num(v) <= 0) return;
                        o.offerFare = Store.num(v); o.offerBy = Store.phone; o.status = "OFFER";
                        Store.notify(o.customer, "Driver asks ₹" + o.offerFare + " for #" + o.id); refresh(); })));
        } else {
            for (int i = Store.d.orders.size() - 1; i >= 0; i--) {
                Store.Order o = Store.d.orders.get(i);
                boolean mine = Store.phone.equals(o.transporter), pending = o.status.equals("OFFER") && Store.phone.equals(o.offerBy);
                if (!mine && !pending) continue;
                String sub = o.village + " → " + o.dest + " · ₹" + (pending ? o.offerFare : o.fare);
                if (o.payment.equals("COD") && !o.paid) sub += "\n" + getString(R.string.collect, o.total());
                Row r = new Row("#" + o.id + " " + o.crop + " · " + o.qty + " kg", sub)
                    .chip(Store.statusText(this, o), Store.color(o.status));
                if (o.status.equals("ASSIGNED"))
                    r.btn(getString(R.string.picked_up), () -> {
                        o.status = "IN_TRANSIT"; Store.notify(o.customer, "Order #" + o.id + " left the farm, ETA ~45 min"); refresh(); });
                else if (o.status.equals("IN_TRANSIT"))
                    r.btn(getString(R.string.confirm_delivery), () -> RowAdapter.prompt(this, getString(R.string.customer_otp), otp -> {
                        if (otp.equals(o.otp)) {
                            o.status = "DELIVERED"; o.paid = true;
                            Store.notify(o.customer, "Order #" + o.id + " delivered"); Store.notify(o.farmer, "Order #" + o.id + " delivered");
                        } else toast(getString(R.string.wrong_otp));
                        refresh(); }));
                rows.add(r);
            }
        }
        return rows;
    }
}
