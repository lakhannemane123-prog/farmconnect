package com.farmconnect;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import com.farmconnect.RowAdapter.Row;
import java.util.*;

public class FarmerActivity extends BaseActivity {
    private String pendingPhoto; private ImageView dlPhoto; private Spinner dlCrop;

    private final ActivityResultLauncher<Intent> cam = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), r -> {
            if (r.getData() != null && r.getData().getExtras() != null) {
                Bitmap b = (Bitmap) r.getData().getExtras().get("data");
                if (b != null) { pendingPhoto = Store.encode(b); if (dlPhoto != null) dlPhoto.setImageBitmap(b); }
            }
        });

    @Override protected int navMenu() { return R.menu.nav_farmer; }
    @Override protected boolean hasFab() { return true; }

    @Override protected String summary(int t) {
        if (t != R.id.t2) return null;
        int sum = 0, n = 0;
        for (Store.Order o : Store.d.orders) if (o.farmer.equals(Store.phone) && o.status.equals("DELIVERED")) { sum += o.total(); n++; }
        return getString(R.string.earned, sum, n);
    }

    @Override protected List<Row> rows(int t) {
        List<Row> rows = new ArrayList<>();
        if (t == R.id.t1) {
            for (Store.Listing l : Store.d.listings) {
                if (!l.farmer.equals(Store.phone)) continue;
                boolean out = l.qty <= 0;
                rows.add(new Row(l.crop + " · ₹" + l.price + "/kg", l.village + " · " + l.qty + " kg")
                    .photo(l.photo).chip(getString(out ? R.string.sold_out : R.string.available), out ? 0xFFC62828 : 0xFF2E7D32)
                    .btn(getString(R.string.edit_price), () -> RowAdapter.prompt(this, getString(R.string.new_price), v -> {
                        if (Store.num(v) > 0) { l.price = Store.num(v); refresh(); } }))
                    .btn(getString(R.string.delete), () -> { Store.d.listings.remove(l); refresh(); }));
            }
        } else {
            for (int i = Store.d.orders.size() - 1; i >= 0; i--) {
                Store.Order o = Store.d.orders.get(i);
                if (!o.farmer.equals(Store.phone)) continue;
                String sub = o.customer + " → " + o.dest + " · ₹" + o.total() + " (" + o.payment + (o.paid ? " ✔" : "") + ")";
                if (o.status.equals("ASSIGNED")) sub += "\n" + getString(R.string.pickup_eta, o.transporter);   // pickup alert
                if (o.issue != null) sub += "\n⚠ " + getString(R.string.issue_label, o.issue) + (o.issueResolved ? " ✔" : "");
                Row r = new Row("#" + o.id + " " + o.crop + " · " + o.qty + " kg", sub)
                    .chip(Store.statusText(this, o), Store.color(o.status));
                if (o.status.equals("PLACED")) {
                    r.btn(getString(R.string.accept), () -> {
                        o.status = "ACCEPTED"; Store.notify(o.customer, "Order #" + o.id + " accepted by farmer"); refresh(); });
                    r.btn(getString(R.string.reject), () -> {
                        o.status = "REJECTED"; Store.restock(o); Store.notify(o.customer, "Order #" + o.id + " rejected"); refresh(); });
                }
                if (o.issue != null && !o.issueResolved)
                    r.btn(getString(R.string.resolve), () -> {
                        o.issueResolved = true; Store.notify(o.customer, "Issue on order #" + o.id + " resolved"); refresh(); });
                rows.add(r);
            }
        }
        return rows;
    }

    @Override protected void onFab() {
        View v = getLayoutInflater().inflate(R.layout.dialog_listing, null);
        dlCrop = v.findViewById(R.id.dlCrop); dlPhoto = v.findViewById(R.id.dlPhoto);
        Spinner place = v.findViewById(R.id.dlPlace);
        EditText q = v.findViewById(R.id.dlQty), p = v.findViewById(R.id.dlPrice);
        pendingPhoto = null;
        v.findViewById(R.id.dlMic).setOnClickListener(x -> listen());
        v.findViewById(R.id.dlPhotoBtn).setOnClickListener(x -> {
            try { cam.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE)); } catch (Exception e) { toast("No camera"); }
        });
        new AlertDialog.Builder(this).setTitle(R.string.list_produce).setView(v)
            .setPositiveButton(R.string.list_produce, (d, w) -> {
                int qty = Store.num(q.getText().toString()), price = Store.num(p.getText().toString());
                if (qty <= 0 || price <= 0) { toast(getString(R.string.fill_all)); return; }
                Store.add(Store.phone, place.getSelectedItem().toString(), dlCrop.getSelectedItem().toString(), qty, price, pendingPhoto);
                refresh();
            }).setNegativeButton(R.string.cancel, null).show();
    }

    @Override protected void onSpeech(String t) {
        int i = cropFrom(t);
        if (i >= 0 && dlCrop != null) dlCrop.setSelection(i); else toast("Heard: " + t);
    }
}
