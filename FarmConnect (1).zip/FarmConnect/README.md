# FarmConnect v2 (Java + XML)
Android Studio: File > Open this folder > Gradle sync > Run.
VS Code: Extension Pack for Java + Gradle for Java + Android SDK; run `gradle wrapper` once, then `./gradlew installDebug` with an emulator/device attached.
Demo login: any 10-digit number, OTP 1234. Seed farmers: 9000000001, 9000000002.
